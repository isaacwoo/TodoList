class MindMap {
    constructor() {
        this.nodes = [];
        this.connections = [];
        this.textBoxes = []; // 文本框数组
        this.dashedBoxes = []; // 虚线框数组
        this.selectedNode = null;
        this.nodeIdCounter = 0;
        this.textBoxIdCounter = 0;
        this.dashedBoxIdCounter = 0;
        this.canvas = document.getElementById('canvas');
        this.svgCanvas = document.getElementById('svg-canvas');
        this.canvasContainer = document.getElementById('canvas-container');
        this.contextMenu = document.getElementById('context-menu');
        this.canvasContextMenu = document.getElementById('canvas-context-menu');
        this.canvasContextMenuX = 0;
        this.canvasContextMenuY = 0;
        
        // 画布状态
        this.scale = 1;
        this.translateX = 0;
        this.translateY = 0;
        this.isPanning = false;
        this.panStartX = 0;
        this.panStartY = 0;
        
        // 点击检测
        this.mouseDownX = undefined;
        this.mouseDownY = undefined;
        this.mouseDownTime = undefined;

        // 拖拽状态
        this.isDragging = false;
        this.dragNode = null;
        this.dragOffsetX = 0;
        this.dragOffsetY = 0;
        
        // 文本框拖动状态
        this.isDraggingTextBox = false;
        this.dragTextBox = null;
        this.selectedTextBox = null;
        
        // 虚线框拖动和缩放状态
        this.isDraggingDashedBox = false;
        this.dragDashedBox = null;
        this.selectedDashedBox = null;
        this.isResizingDashedBox = false;
        this.resizeDashedBox = null;
        this.resizeHandle = null;

        // 箭头连接状态
        this.arrowConnections = [];
        this.isConnecting = false;
        this.connectionSourceNode = null;
        this.selectedArrow = null; // 当前选中的箭头

        this.init();
    }

    init() {
        this.setupEventListeners();
        this.createRootNode();
        this.initSVGMarkers();
        this.updateCanvas();
    }

    initSVGMarkers() {
        // 创建箭头标记
        const defs = document.createElementNS('http://www.w3.org/2000/svg', 'defs');
        const marker = document.createElementNS('http://www.w3.org/2000/svg', 'marker');
        marker.setAttribute('id', 'arrowhead');
        marker.setAttribute('markerWidth', '10');
        marker.setAttribute('markerHeight', '10');
        marker.setAttribute('refX', '9');
        marker.setAttribute('refY', '3');
        marker.setAttribute('orient', 'auto');
        
        const polygon = document.createElementNS('http://www.w3.org/2000/svg', 'polygon');
        polygon.setAttribute('points', '0 0, 10 3, 0 6');
        polygon.setAttribute('fill', '#FF6B6B');
        
        marker.appendChild(polygon);
        defs.appendChild(marker);
        this.svgCanvas.appendChild(defs);
    }

    setupEventListeners() {
        // 键盘事件
        document.addEventListener('keydown', (e) => this.handleKeyDown(e));
        document.addEventListener('keyup', (e) => this.handleKeyUp(e));

        // 鼠标事件
        this.canvasContainer.addEventListener('mousedown', (e) => this.handleMouseDown(e));
        document.addEventListener('mousemove', (e) => this.handleMouseMove(e));
        document.addEventListener('mouseup', (e) => this.handleMouseUp(e));
        
        // 双击事件
        this.canvasContainer.addEventListener('dblclick', (e) => this.handleCanvasDblClick(e));
        
        // 画布右键菜单
        this.canvasContainer.addEventListener('contextmenu', (e) => this.handleCanvasContextMenu(e));
        
        // 画布点击事件，取消选中
        this.canvas.addEventListener('click', (e) => {
            if (e.target === this.canvas) {
                // 取消所有选中
                if (this.selectedNode) {
                    this.selectedNode.element.classList.remove('selected');
                    this.selectedNode = null;
                }
                if (this.selectedTextBox) {
                    this.selectedTextBox.element.classList.remove('selected');
                    this.selectedTextBox = null;
                }
                if (this.selectedDashedBox) {
                    this.selectedDashedBox.element.classList.remove('selected');
                    this.selectedDashedBox = null;
                }
                this.selectedArrow = null;
            }
        });

        // 滚轮缩放
        this.canvasContainer.addEventListener('wheel', (e) => this.handleWheel(e));

        // 隐藏所有右键菜单
        document.addEventListener('click', () => {
            this.hideContextMenu();
            this.hideCanvasContextMenu();
        });

        // 窗口大小改变
        window.addEventListener('resize', () => this.updateCanvas());
    }

    createRootNode() {
        const node = {
            id: this.nodeIdCounter++,
            text: '中心主题',
            x: 2400,
            y: 2470,
            parent: null,
            children: [],
            isRoot: true,
            color: null
        };
        this.nodes.push(node);
        this.createNodeElement(node);
        
        // 初始化视图，使根节点居中
        setTimeout(() => {
            const container = this.canvasContainer.getBoundingClientRect();
            this.translateX = container.width / 2 - 2450 * this.scale;
            this.translateY = (container.height - 60) / 2 - 2500 * this.scale;
            this.updateCanvas();
            
            // 默认选中根节点
            this.selectNode(node);
        }, 0);
    }

    createNodeElement(node) {
        const nodeEl = document.createElement('div');
        nodeEl.className = 'node' + (node.isRoot ? ' root' : '');
        
        // 添加形状类
        const shape = node.shape || 'rectangle';
        nodeEl.classList.add(`shape-${shape}`);
        
        nodeEl.id = `node-${node.id}`;
        nodeEl.style.left = node.x + 'px';
        nodeEl.style.top = node.y + 'px';
        
        if (node.color && !node.isRoot) {
            nodeEl.style.backgroundColor = node.color;
            if (node.color == '#FFFFFF') {
                nodeEl.style.color =  'black';
            } else {
                nodeEl.style.color =  'white';
            }
            
        }

        const textEl = document.createElement('div');
        textEl.className = 'node-text';
        textEl.textContent = node.text;
        nodeEl.appendChild(textEl);

        // 折叠/展开按钮（默认隐藏，只有在有子节点时显示）
        const collapseBtn = document.createElement('div');
        collapseBtn.className = 'collapse-btn';
        collapseBtn.style.display = 'none';
        collapseBtn.textContent = '\u2212'; // 默认为展开状态时显示减号
        collapseBtn.title = '折叠/展开子节点';
        collapseBtn.addEventListener('click', (e) => {
            e.stopPropagation();
            this.toggleCollapse(node);
        });
        nodeEl.appendChild(collapseBtn);
        node._collapseBtn = collapseBtn;
        this.updateCollapseButton(node); // 在节点创建后立即更新折叠按钮状态

        // 点击选择
        nodeEl.addEventListener('click', (e) => {
            e.stopPropagation();
            this.selectNode(node);
        });

        // 双击编辑
        nodeEl.addEventListener('dblclick', (e) => {
            e.stopPropagation();
            this.editNode(node);
        });

        // 右键菜单
        nodeEl.addEventListener('contextmenu', (e) => {
            e.preventDefault();
            e.stopPropagation();
            this.selectNode(node);
            this.showContextMenu(e.clientX, e.clientY);
        });

        // 拖拽开始
        nodeEl.addEventListener('mousedown', (e) => {
            if (e.button === 0) {
                e.stopPropagation(); // 阻止事件冒泡到画布
                this.startDragging(node, e);
            }
        });

    this.canvas.appendChild(nodeEl);
    node.element = nodeEl;
    // 为 node 对象保存按钮引用，便于后续更新
    node._collapseBtn = collapseBtn;
    }

    createIndependentTopic(clientX, clientY) {
        const containerRect = this.canvasContainer.getBoundingClientRect();
        
        // 将屏幕坐标转换为画布坐标
        const x = (clientX - containerRect.left - this.translateX) / this.scale;
        const y = (clientY - containerRect.top - 60 - this.translateY) / this.scale;
        
        const node = {
            id: this.nodeIdCounter++,
            text: '新主题',
            x: x - 50, // 居中显示
            y: y - 20,
            parent: null,
            children: [],
            isRoot: false,
            isNewRoot: true,
            color: '#4A90E2'
        };
        
        this.nodes.push(node);
        this.createNodeElement(node);
        this.selectNode(node);
        
        // 自动进入编辑模式
        setTimeout(() => this.editNode(node), 50);
    }

    selectNode(node) {
        // 取消文本框选中
        if (this.selectedTextBox) {
            this.selectedTextBox.element.classList.remove('selected');
            this.selectedTextBox = null;
        }
        
        // 取消虚线框选中
        if (this.selectedDashedBox) {
            this.selectedDashedBox.element.classList.remove('selected');
            this.selectedDashedBox = null;
        }
        
        if (this.selectedNode) {
            this.selectedNode.element.classList.remove('selected');
        }
        this.selectedNode = node;
        node.element.classList.add('selected');
    }

    // 判断节点是否应当被视为“可见”（用于决定是否绘制连接线等）
    isNodeVisible(node) {
        if (!node || !node.element) return false;
        // 如果元素被隐藏（display: none）则认为不可见
        if (node.element.style.display === 'none') return false;
        // 如果任一祖先节点处于折叠状态，则当前节点也不可见
        let p = node.parent;
        while (p) {
            if (p.collapsed) return false;
            p = p.parent;
        }
        return true;
    }

    // 更新父节点上的折叠/展开按钮显示
    updateCollapseButton(node) {
        if (!node || !node._collapseBtn) return;
        if (node.isRoot) { 
            node._collapseBtn.style.display = 'none'; 
            return; 
        }
        if (node.children && node.children.length > 0) {
            node._collapseBtn.style.display = '';
            node._collapseBtn.textContent = node.collapsed ? '+' : '\u2212';
            const root = this.getRootNode(node);
            const layout = (root && root.layout) ? root.layout : 'horizontal';
            node._collapseBtn.classList.remove('pos-right', 'pos-bottom');
            node._collapseBtn.classList.add(layout === 'horizontal' ? 'pos-right' : 'pos-bottom');
        } else {
            node._collapseBtn.style.display = 'none';
            node._collapseBtn.classList.remove('pos-right', 'pos-bottom');
        }
    }

    getRootNode(node) {
        if (!node) return null;
        let r = node;
        while (r.parent) r = r.parent;
        return r;
    }

    // 切换折叠状态
    toggleCollapse(node) {
        if (!node) return;
        node.collapsed = !node.collapsed;
        if (node.collapsed) {
            this.collapseNode(node);
        } else {
            this.expandNode(node);
        }
        this.updateCollapseButton(node);
        this.updateConnections();
    }

    // 隐藏节点的所有子孙（不修改子节点的 collapsed 标志）
    collapseNode(node) {
        const hideRecursive = (n) => {
            n.children.forEach(c => {
                if (c.element) c.element.style.display = 'none';
                hideRecursive(c);
            });
        };
        hideRecursive(node);
    }

    // 展示节点的直接子节点（若子节点本身 collapsed 则保留其子孙隐藏）
    expandNode(node) {
        node.children.forEach(c => {
            if (c.element) c.element.style.display = '';
            // 如果子节点本身被折叠，则其子孙应保持隐藏
            if (c.collapsed) {
                const hideRecursive = (n) => {
                    n.children.forEach(ch => {
                        if (ch.element) ch.element.style.display = 'none';
                        hideRecursive(ch);
                    });
                };
                hideRecursive(c);
            }
        });
    }

    addChildNode() {
        if (!this.selectedNode) return;

        const parent = this.selectedNode;
        const childCount = parent.children.length;
        
        // 查找根节点以获取布局方向
        let rootNode = parent;
        while (rootNode.parent !== null) {
            rootNode = rootNode.parent;
        }
        const layout = rootNode.layout || 'horizontal';
        
        let x, y;
        
        if (layout === 'horizontal') {
            // 横向布局：子节点在右侧垂直排列
            const startY = parent.y - childCount * 40;
            x = parent.x + 200;
            y = startY + childCount * 80;
        } else {
            // 纵向布局：子节点在下方横向排列
            const startX = parent.x - childCount * 60;
            x = startX + childCount * 120;
            y = parent.y + 120;
        }
        
        const node = {
            id: this.nodeIdCounter++,
            text: '新节点',
            x: x,
            y: y,
            parent: parent,
            children: [],
            isRoot: false,
            color: parent.color
        };

        this.nodes.push(node);
        parent.children.push(node);
        this.createNodeElement(node);
        // 新增子节点后更新父节点的折叠按钮显示
        this.updateCollapseButton(parent);
        // 如果父节点处于折叠状态，则新创建的子节点保持隐藏
        if (parent.collapsed) {
            node.element.style.display = 'none';
        }
        this.updateConnections();
        this.selectNode(node);
        
        // 自动进入编辑模式
        setTimeout(() => this.editNode(node), 50);
    }

    addSiblingNode() {
        if (!this.selectedNode || !this.selectedNode.parent) return;

        const sibling = this.selectedNode;
        const parent = sibling.parent;
        
        // 查找根节点以获取布局方向
        let rootNode = parent;
        while (rootNode.parent !== null) {
            rootNode = rootNode.parent;
        }
        const layout = rootNode.layout || 'horizontal';
        
        let x, y;
        
        if (layout === 'horizontal') {
            // 横向布局：兄弟节点在下方
            x = sibling.x;
            y = sibling.y + 80;
        } else {
            // 纵向布局：兄弟节点在右侧
            x = sibling.x + 120;
            y = sibling.y;
        }
        
        const node = {
            id: this.nodeIdCounter++,
            text: '新节点',
            x: x,
            y: y,
            parent: parent,
            children: [],
            isRoot: false,
            color: parent.color
        };

        this.nodes.push(node);
        parent.children.push(node);
        this.createNodeElement(node);
        // 新增兄弟节点后更新父节点的折叠按钮显示
        this.updateCollapseButton(parent);
        // 如果父节点处于折叠状态，则新创建的兄弟节点保持隐藏
        if (parent.collapsed) {
            node.element.style.display = 'none';
        }

        // 重新布局所有兄弟节点以保持整齐
        this.relayoutTree(rootNode);
        
        this.updateConnections();
        this.selectNode(node);
        
        // 自动进入编辑模式
        setTimeout(() => this.editNode(node), 50);
    }

    deleteNode(node = this.selectedNode) {
        if (!node || node.isRoot) return;

        // 保存父节点和根节点引用
        const parent = node.parent;
        let rootNode = node;
        while (rootNode.parent !== null) {
            rootNode = rootNode.parent;
        }

        // 递归删除所有子节点
        const deleteRecursive = (n) => {
            n.children.forEach(child => deleteRecursive(child));
            
            // 删除与此节点相关的所有箭头连接
            this.arrowConnections = this.arrowConnections.filter(
                conn => conn.source !== n && conn.target !== n
            );
            
            n.element.remove();
            const index = this.nodes.indexOf(n);
            if (index > -1) {
                this.nodes.splice(index, 1);
            }
        };

        // 从父节点移除
        if (parent) {
            const index = parent.children.indexOf(node);
            if (index > -1) {
                parent.children.splice(index, 1);
                // 删除子节点后更新父节点的折叠按钮显示
                this.updateCollapseButton(parent);
            }
        }

        deleteRecursive(node);
        this.selectedNode = null;
        
        // 重新布局以保持整齐
        if (rootNode) {
            this.relayoutTree(rootNode);
        }
        
        this.updateConnections();
    }

    editNode(node = this.selectedNode) {
        if (!node) return;

        const nodeEl = node.element;
        const textEl = nodeEl.querySelector('.node-text');
        
        nodeEl.classList.add('editing');
        
        // 使用textarea支持多行
        const textarea = document.createElement('textarea');
        textarea.className = 'node-input';
        textarea.value = node.text;
        textarea.style.width = Math.max(100, textEl.offsetWidth + 20) + 'px';
        textarea.style.minHeight = Math.max(40, textEl.offsetHeight + 10) + 'px';
        textarea.style.resize = 'both';
        textarea.style.overflow = 'auto';
        textarea.rows = 1;
        
        textEl.style.display = 'none';
        nodeEl.appendChild(textarea);
        textarea.focus();
        textarea.select();
        
        // 自动调整高度
        const autoResize = () => {
            textarea.style.height = 'auto';
            textarea.style.height = textarea.scrollHeight + 'px';
        };
        autoResize();

        const finishEditing = () => {
            node.text = textarea.value || '新节点';
            textEl.textContent = node.text;
            textEl.style.display = 'block';
            textarea.remove();
            nodeEl.classList.remove('editing');
            
            // 更新连接线
            this.updateConnections();
        };

        textarea.addEventListener('blur', finishEditing);
        textarea.addEventListener('input', autoResize);
        textarea.addEventListener('keydown', (e) => {
            if (e.key === 'Enter' && e.ctrlKey) {
                // Ctrl+Enter 换行
                e.preventDefault();
                const start = textarea.selectionStart;
                const end = textarea.selectionEnd;
                const value = textarea.value;
                textarea.value = value.substring(0, start) + '\n' + value.substring(end);
                textarea.selectionStart = textarea.selectionEnd = start + 1;
                autoResize();
            } else if (e.key === 'Enter' && !e.ctrlKey && !e.shiftKey) {
                // Enter 确认
                e.preventDefault();
                finishEditing();
            } else if (e.key === 'Escape') {
                e.preventDefault();
                textarea.value = node.text;
                finishEditing();
            }
            e.stopPropagation();
        });
    }

    updateConnections() {
        // 清空SVG（但保留defs）
        const defs = this.svgCanvas.querySelector('defs');
        this.svgCanvas.innerHTML = '';
        if (defs) {
            this.svgCanvas.appendChild(defs);
        }

        // 绘制所有父子连接（跳过不可见的节点或父节点）
        this.nodes.forEach(node => {
            if (node.parent) {
                if (this.isNodeVisible(node) && this.isNodeVisible(node.parent)) {
                    this.drawConnection(node.parent, node);
                }
            }
        });

        // 绘制所有箭头连接
        this.arrowConnections.forEach(conn => {
            if (conn.isTemporary) {
                // 临时箭头，使用自由端点
                this.drawArrowConnection(conn.source, null, true, conn.endX, conn.endY);
            } else if (conn.target) {
                // 正常箭头
                this.drawArrowConnection(conn.source, conn.target, false);
            }
        });
    }

    drawConnection(parent, child) {
        // 直接使用节点的坐标和尺寸
        const parentEl = parent.element;
        const childEl = child.element;
        
        // 获取节点中心点坐标
        const x1 = parent.x + parentEl.offsetWidth / 2;
        const y1 = parent.y + parentEl.offsetHeight / 2;
        const x2 = child.x + childEl.offsetWidth / 2;
        const y2 = child.y + childEl.offsetHeight / 2;

        // 创建直线路径
        const path = document.createElementNS('http://www.w3.org/2000/svg', 'path');
        const d = `M ${x1} ${y1} L ${x2} ${y2}`;
        
        path.setAttribute('d', d);
        path.setAttribute('class', 'connection');
        if (child.color) {
            path.setAttribute('stroke', child.color);
        }
        
        this.svgCanvas.appendChild(path);
    }

    drawArrowConnection(sourceNode, targetNode, isTemp = false, tempEndX = null, tempEndY = null) {
        if (!sourceNode.element) return;
        
        const sourceEl = sourceNode.element;
        
        // 获取源节点中心点坐标
        const x1 = sourceNode.x + sourceEl.offsetWidth / 2;
        const y1 = sourceNode.y + sourceEl.offsetHeight / 2;
        
        let x2, y2, endX, endY;
        
        if (isTemp && tempEndX !== null && tempEndY !== null) {
            // 临时箭头，使用提供的终点坐标
            endX = tempEndX;
            endY = tempEndY;
        } else if (targetNode) {
            // 判断目标是节点还是虚线框
            let targetWidth, targetHeight;
            
            if (targetNode.element && targetNode.element.classList.contains('node')) {
                // 目标是节点
                const targetEl = targetNode.element;
                x2 = targetNode.x + targetEl.offsetWidth / 2;
                y2 = targetNode.y + targetEl.offsetHeight / 2;
                targetWidth = targetEl.offsetWidth;
                targetHeight = targetEl.offsetHeight;
            } else if (targetNode.element && targetNode.element.classList.contains('dashed-box')) {
                // 目标是虚线框
                x2 = targetNode.x + targetNode.width / 2;
                y2 = targetNode.y + targetNode.height / 2;
                targetWidth = targetNode.width;
                targetHeight = targetNode.height;
            } else {
                return;
            }

            // 计算方向和距离
            const dx = x2 - x1;
            const dy = y2 - y1;
            const distance = Math.sqrt(dx * dx + dy * dy);
            
            if (distance === 0) return;
            
            // 单位向量
            const ux = dx / distance;
            const uy = dy / distance;
            
            // 计算到目标边界的距离
            const angle = Math.abs(Math.atan2(dy, dx));
            let distanceToEdge;
            
            if (angle < Math.atan2(targetHeight, targetWidth)) {
                distanceToEdge = Math.abs((targetWidth / 2) / Math.cos(Math.atan2(dy, dx)));
            } else {
                distanceToEdge = Math.abs((targetHeight / 2) / Math.sin(Math.atan2(dy, dx)));
            }
            
            endX = x2 - ux * (distanceToEdge + 8);
            endY = y2 - uy * (distanceToEdge + 8);
        } else {
            return;
        }

        // 创建带箭头的路径
        const path = document.createElementNS('http://www.w3.org/2000/svg', 'path');
        const d = `M ${x1} ${y1} L ${endX} ${endY}`;
        
        path.setAttribute('d', d);
        path.setAttribute('class', 'arrow-connection');
        path.setAttribute('stroke', '#FF6B6B');
        
        if (isTemp) {
            path.setAttribute('stroke-dasharray', '5,5');
            path.style.opacity = '0.6';
        }
        
        // 存储连接信息
        if (!isTemp) {
            path.dataset.sourceId = sourceNode.id;
            if (targetNode.id !== undefined) {
                path.dataset.targetId = targetNode.id;
            }
        }
        
        // 添加箭头头部的拖动点（圆圈）
        const circle = document.createElementNS('http://www.w3.org/2000/svg', 'circle');
        circle.setAttribute('cx', endX);
        circle.setAttribute('cy', endY);
        circle.setAttribute('r', '8');
        circle.setAttribute('fill', isTemp ? '#FF6B6B' : 'white');
        circle.setAttribute('stroke', '#FF6B6B');
        circle.setAttribute('stroke-width', '2');
        circle.style.cursor = 'move';
        circle.style.pointerEvents = 'auto';
        
        // 拖动功能
        let isDraggingArrow = false;
        let arrowConnection = null;
        
        if (isTemp) {
            // 临时箭头，存储引用
            arrowConnection = this.arrowConnections.find(c => c.source === sourceNode && c.isTemporary);
        }
        
        circle.addEventListener('mousedown', (e) => {
            e.stopPropagation();
            isDraggingArrow = true;
            
            let currentHighlightTarget = null; // 当前高亮的目标
            
            if (!isTemp) {
                // 将现有箭头转换为临时状态
                arrowConnection = this.arrowConnections.find(
                    c => c.source.id === parseInt(path.dataset.sourceId) && 
                         c.target && c.target.id === parseInt(path.dataset.targetId)
                );
                if (arrowConnection) {
                    arrowConnection.target = null;
                    arrowConnection.isTemporary = true;
                    arrowConnection.endX = endX;
                    arrowConnection.endY = endY;
                }
            }
            
            const onMouseMove = (e) => {
                if (!isDraggingArrow) return;
                
                const containerRect = this.canvasContainer.getBoundingClientRect();
                const x = (e.clientX - containerRect.left - this.translateX) / this.scale;
                const y = (e.clientY - containerRect.top - 60 - this.translateY) / this.scale;
                
                if (arrowConnection) {
                    arrowConnection.endX = x;
                    arrowConnection.endY = y;
                    
                    // 查找最近的目标进行高亮
                    let closestTarget = null;
                    let minDistance = 50;
                    
                    // 检查节点
                    this.nodes.forEach(node => {
                        if (node === arrowConnection.source) return;
                        
                        const nodeEl = node.element;
                        const nodeCenterX = node.x + nodeEl.offsetWidth / 2;
                        const nodeCenterY = node.y + nodeEl.offsetHeight / 2;
                        const dist = Math.sqrt(Math.pow(x - nodeCenterX, 2) + Math.pow(y - nodeCenterY, 2));
                        
                        if (dist < minDistance) {
                            minDistance = dist;
                            closestTarget = node;
                        }
                    });
                    
                    // 检查虚线框
                    this.dashedBoxes.forEach(box => {
                        const boxCenterX = box.x + box.width / 2;
                        const boxCenterY = box.y + box.height / 2;
                        const dist = Math.sqrt(Math.pow(x - boxCenterX, 2) + Math.pow(y - boxCenterY, 2));
                        
                        if (dist < minDistance) {
                            minDistance = dist;
                            closestTarget = box;
                        }
                    });
                    
                    // 更新高亮状态
                    if (closestTarget !== currentHighlightTarget) {
                        // 移除之前的高亮
                        if (currentHighlightTarget && currentHighlightTarget.element) {
                            currentHighlightTarget.element.classList.remove('arrow-target-highlight');
                        }
                        
                        // 添加新的高亮
                        if (closestTarget && closestTarget.element) {
                            closestTarget.element.classList.add('arrow-target-highlight');
                        }
                        
                        currentHighlightTarget = closestTarget;
                    }
                    
                    this.updateConnections();
                }
            };
            
            const onMouseUp = (e) => {
                isDraggingArrow = false;
                
                // 移除高亮
                if (currentHighlightTarget && currentHighlightTarget.element) {
                    currentHighlightTarget.element.classList.remove('arrow-target-highlight');
                }
                
                document.removeEventListener('mousemove', onMouseMove);
                document.removeEventListener('mouseup', onMouseUp);
                
                if (arrowConnection) {
                    // 查找最近的节点或虚线框
                    const containerRect = this.canvasContainer.getBoundingClientRect();
                    const x = (e.clientX - containerRect.left - this.translateX) / this.scale;
                    const y = (e.clientY - containerRect.top - 60 - this.translateY) / this.scale;
                    
                    let closestTarget = null;
                    let minDistance = 50; // 最大捕捉距离
                    let targetType = null; // 'node' 或 'dashedBox'
                    
                    // 检查节点
                    this.nodes.forEach(node => {
                        if (node === arrowConnection.source) return;
                        
                        const nodeEl = node.element;
                        const nodeCenterX = node.x + nodeEl.offsetWidth / 2;
                        const nodeCenterY = node.y + nodeEl.offsetHeight / 2;
                        const dist = Math.sqrt(Math.pow(x - nodeCenterX, 2) + Math.pow(y - nodeCenterY, 2));
                        
                        if (dist < minDistance) {
                            minDistance = dist;
                            closestTarget = node;
                            targetType = 'node';
                        }
                    });
                    
                    // 检查虚线框
                    this.dashedBoxes.forEach(box => {
                        const boxCenterX = box.x + box.width / 2;
                        const boxCenterY = box.y + box.height / 2;
                        const dist = Math.sqrt(Math.pow(x - boxCenterX, 2) + Math.pow(y - boxCenterY, 2));
                        
                        if (dist < minDistance) {
                            minDistance = dist;
                            closestTarget = box;
                            targetType = 'dashedBox';
                        }
                    });
                    
                    if (closestTarget) {
                        // 连接到最近的目标
                        arrowConnection.target = closestTarget;
                        arrowConnection.targetType = targetType;
                        arrowConnection.isTemporary = false;
                        delete arrowConnection.endX;
                        delete arrowConnection.endY;
                    } else if (!arrowConnection.target) {
                        // 如果没有找到目标且没有目标，删除临时箭头
                        this.arrowConnections = this.arrowConnections.filter(c => c !== arrowConnection);
                    }
                    
                    this.updateConnections();
                }
            };
            
            document.addEventListener('mousemove', onMouseMove);
            document.addEventListener('mouseup', onMouseUp);
        });
        
        // 选中功能（用于Delete键删除）
        if (!isTemp) {
            path.style.cursor = 'pointer';
            circle.addEventListener('click', (e) => {
                e.stopPropagation();
                // 选中这个箭头
                this.selectedArrow = {source: sourceNode, target: targetNode};
                // 高亮显示
                path.setAttribute('stroke-width', '3');
                path.setAttribute('stroke', '#FF4444');
            });
        }
        
        this.svgCanvas.appendChild(path);
        this.svgCanvas.appendChild(circle);
    }

    startDragging(node, e) {
        this.isDragging = true;
        this.dragNode = node;
        
        const rect = node.element.getBoundingClientRect();
        this.dragOffsetX = e.clientX - rect.left;
        this.dragOffsetY = e.clientY - rect.top;
        
        this.selectNode(node);
    }

    handleMouseDown(e) {
        // 如果点击的是画布容器本身（空白区域），开始拖动画布
        if (e.target === this.canvasContainer || e.target === this.canvas || e.target === this.svgCanvas) {
            if (e.button === 0) {
                this.isPanning = true;
                this.panStartX = e.clientX - this.translateX;
                this.panStartY = e.clientY - this.translateY;
                this.canvasContainer.classList.add('grabbing');
                e.preventDefault();
            }
        }
    }

    handleMouseMove(e) {
        if (this.isDragging && this.dragNode) {
            const containerRect = this.canvasContainer.getBoundingClientRect();
            const x = (e.clientX - containerRect.left - this.dragOffsetX) / this.scale - this.translateX / this.scale;
            const y = (e.clientY - containerRect.top - 60 - this.dragOffsetY) / this.scale - this.translateY / this.scale;
            
            const dx = x - this.dragNode.x;
            const dy = y - this.dragNode.y;
            
            // 移动节点及其所有子节点
            this.moveNodeRecursive(this.dragNode, dx, dy);
            
            // 使用requestAnimationFrame优化重绘
            requestAnimationFrame(() => {
                this.updateConnections();
            });
        } else if (this.isPanning) {
            this.translateX = e.clientX - this.panStartX;
            this.translateY = e.clientY - this.panStartY;
            this.updateCanvas();
        }
    }

    handleMouseUp(e) {
        // 如果刚刚拖动了节点，标记为手动调整
        if (this.isDragging && this.dragNode) {
            this.dragNode.manuallyPositioned = true;
            // 递归标记所有子节点
            const markChildren = (node) => {
                node.manuallyPositioned = true;
                node.children.forEach(child => markChildren(child));
            };
            markChildren(this.dragNode);
        }
        
        this.isDragging = false;
        this.dragNode = null;
        this.isPanning = false;
        this.isDraggingTextBox = false;
        this.dragTextBox = null;
        this.isDraggingDashedBox = false;
        this.dragDashedBox = null;
        this.isResizingDashedBox = false;
        this.resizeDashedBox = null;
        this.resizeHandle = null;
        this.canvasContainer.classList.remove('grabbing');
    }

    handleCanvasDblClick(e) {
        // 双击空白区域创建独立主题
        if (e.target === this.canvasContainer || e.target === this.canvas || e.target === this.svgCanvas) {
            const containerRect = this.canvasContainer.getBoundingClientRect();
            // 计算双击位置在画布坐标系中的位置
            const x = (e.clientX - containerRect.left - this.translateX) / this.scale;
            const y = (e.clientY - containerRect.top - 60 - this.translateY) / this.scale;
            
            this.createIndependentNode(x, y);
        }
    }

    createIndependentNode(x, y) {
        const node = {
            id: this.nodeIdCounter++,
            text: '新主题',
            x: x - 50, // 居中偏移
            y: y - 20,
            parent: null,
            children: [],
            isRoot: false,
            isNewRoot: true,
            color: '#4A90E2',
            layout: 'horizontal' // 默认横向布局
        };
        
        this.nodes.push(node);
        this.createNodeElement(node);
        this.selectNode(node);
        
        // 自动进入编辑模式
        setTimeout(() => this.editNode(node), 50);
    }

    moveNodeRecursive(node, dx, dy) {
        node.x += dx;
        node.y += dy;
        node.element.style.left = node.x + 'px';
        node.element.style.top = node.y + 'px';
        
        node.children.forEach(child => this.moveNodeRecursive(child, dx, dy));
    }

    handleKeyDown(e) {
        if (e.key === 'Shift' && this.selectedNode) {
            e.preventDefault();
            this.cycleNodeShape();
        } else if (e.key === 'l' && e.ctrlKey) {
            e.preventDefault();
            this.startArrowConnection();
        } else if (e.key === 'Tab' && !e.target.classList.contains('node-input')) {
            e.preventDefault();
            this.addChildNode();
        } else if (e.key === 'Enter' && !e.target.classList.contains('node-input')) {
            e.preventDefault();
            this.addSiblingNode();
        } else if (e.key === 'Delete' || e.key === 'Backspace') {
            if (!e.target.classList.contains('node-input')) {
                e.preventDefault();
                // 先检查是否有选中的箭头
                if (this.selectedArrow) {
                    this.deleteArrowConnection(this.selectedArrow.source, this.selectedArrow.target);
                    this.selectedArrow = null;
                } else {
                    this.deleteNode();
                }
            }
        } else if (e.key === 'F2') {
            e.preventDefault();
            this.editNode();
        } else if (e.key === '+' || e.key === '=') {
            e.preventDefault();
            this.zoomIn();
        } else if (e.key === '-') {
            e.preventDefault();
            this.zoomOut();
        } else if (e.key === 'Home') {
            e.preventDefault();
            this.resetView();
        } else if (e.key === '?') {
            this.toggleHelp();
        } else if ((e.key === 'f' || e.key === 'F') && e.altKey) {
  e.preventDefault();
  if (this.selectedNode) this.toggleCollapse(this.selectedNode);
}
    }

    handleKeyUp(e) {
        // 保留以便将来扩展
    }

    handleWheel(e) {
        e.preventDefault();
        const delta = e.deltaY > 0 ? 0.9 : 1.1;
        this.scale *= delta;
        this.scale = Math.max(0.1, Math.min(3, this.scale));
        this.updateCanvas();
    }

    zoomIn() {
        this.scale *= 1.2;
        this.scale = Math.min(3, this.scale);
        this.updateCanvas();
    }

    zoomOut() {
        this.scale *= 0.8;
        this.scale = Math.max(0.1, this.scale);
        this.updateCanvas();
    }

    resetView() {
        this.scale = 1;
        
        // 使用setTimeout确保DOM已更新
        setTimeout(() => {
            // 找到根节点
            const rootNode = this.nodes.find(n => n.isRoot);
            if (rootNode && rootNode.element) {
                const container = this.canvasContainer.getBoundingClientRect();
                // 计算使根节点居中的偏移量
                const nodeWidth = rootNode.element.offsetWidth || 150;
                const nodeHeight = rootNode.element.offsetHeight || 60;
                this.translateX = container.width / 2 - (rootNode.x + nodeWidth / 2) * this.scale;
                this.translateY = (container.height - 60) / 2 - (rootNode.y + nodeHeight / 2) * this.scale;
            } else {
                this.translateX = 0;
                this.translateY = 0;
            }
            
            this.updateCanvas();
        }, 10);
    }

    updateCanvas() {
        const transform = `translate(${this.translateX}px, ${this.translateY}px) scale(${this.scale})`;
        this.canvas.style.transform = transform;
        
        // 延迟更新连接以确保DOM已更新
        requestAnimationFrame(() => {
            this.updateConnections();
        });
    }

    showContextMenu(x, y) {
        // 重新构建菜单内容
        let menuHTML = `<div class="context-menu-item" onclick="mindMap.addChildNode()">添加子节点</div>`;
        
        // 根节点不显示"添加兄弟节点"和"删除节点"选项
        if (this.selectedNode && !this.selectedNode.isRoot && !this.selectedNode.isNewRoot) {
            menuHTML += `<div class="context-menu-item" onclick="mindMap.addSiblingNode()">添加兄弟节点</div>`;
        }
        
        menuHTML += `
            <div class="context-menu-separator"></div>
            <div class="context-menu-item" onclick="mindMap.editNode()">编辑节点</div>
        `;
        
        // 根节点不显示删除选项
        if (this.selectedNode && !this.selectedNode.isRoot) {
            menuHTML += `<div class="context-menu-item" onclick="mindMap.deleteNode()">删除节点</div>`;
        }
        
        menuHTML += `
            <div class="context-menu-separator"></div>
            <div class="context-menu-item" onclick="mindMap.startArrowConnection()">添加连接箭头</div>
        `;
        
        // 检查当前节点是否有箭头连接
        if (this.selectedNode) {
            const outgoingArrows = this.arrowConnections.filter(
                conn => conn.source === this.selectedNode
            );
            
            if (outgoingArrows.length > 0) {
                menuHTML += `<div class="context-menu-item" onclick="mindMap.showDeleteArrowMenu()">删除箭头连接</div>`;
            }
        }
        
        // 只有根节点和独立主题（无父节点）才能切换布局方向
        if (this.selectedNode && !this.selectedNode.parent) {
            const currentLayout = this.selectedNode.layout || 'horizontal';
            const layoutText = currentLayout === 'horizontal' ? '切换为纵向布局' : '切换为横向布局';
            menuHTML += `
                <div class="context-menu-separator"></div>
                <div class="context-menu-item" onclick="mindMap.toggleLayout()">${layoutText}</div>
            `;
        }
        
        menuHTML += `
            <div class="context-menu-separator"></div>
            <div class="context-menu-item" onclick="mindMap.showShapePicker()">更改形状</div>
            <div class="context-menu-item" onclick="mindMap.showColorPicker()">更改颜色</div>
        `;
        
        // 添加折叠/展开子节点选项
        if (this.selectedNode) {
          menuHTML += `<div class="context-menu-separator"></div>`;
          menuHTML += `<div class="context-menu-item" onclick="mindMap.toggleCollapse(mindMap.selectedNode)">${this.selectedNode.collapsed ? '展开子节点' : '折叠子节点'}</div>`;
        }
        
        this.contextMenu.innerHTML = menuHTML;
        this.contextMenu.style.display = 'block';
        this.contextMenu.style.left = x + 'px';
        this.contextMenu.style.top = y + 'px';
    }

    hideContextMenu() {
        this.contextMenu.style.display = 'none';
    }

    showColorPicker() {
        if (!this.selectedNode) return;
        
        const colors = ['#FFFFFF', '#4A90E2', '#50C878', '#FFB347', '#FF6B6B', '#9B59B6', '#1ABC9C'];
        const picker = document.createElement('div');
        picker.className = 'context-menu color-picker';
        picker.style.display = 'flex';
        picker.style.position = 'fixed';
        picker.style.left = this.contextMenu.style.left;
        picker.style.top = (parseInt(this.contextMenu.style.top) + 50) + 'px';
        picker.style.background = 'white';
        picker.style.border = '1px solid #ddd';
        picker.style.borderRadius = '4px';
        picker.style.boxShadow = '0 4px 12px rgba(0,0,0,0.15)';
        picker.style.zIndex = '2001';

        colors.forEach(color => {
            const option = document.createElement('div');
            option.className = 'color-option';
            option.style.background = color;
            option.onclick = () => {
                this.selectedNode.color = color;
                // if (!this.selectedNode.isRoot) {
                    this.selectedNode.element.style.background = color;
                    if (color == '#FFFFFF') {
                        this.selectedNode.element.style.color = 'black';
                    } else {
                        this.selectedNode.element.style.color = 'white';
                    }                   
                // }
                this.updateConnections();
                picker.remove();
            };
            picker.appendChild(option);
        });

        document.body.appendChild(picker);
        setTimeout(() => picker.remove(), 5000);
        this.hideContextMenu();
    }

    showShapePicker() {
        if (!this.selectedNode) return;
        
        const shapes = [
            { name: 'rectangle', label: '矩形' },
            { name: 'rounded', label: '圆角矩形' },
            { name: 'ellipse', label: '椭圆' },
            { name: 'diamond', label: '菱形' },
            { name: 'parallelogram', label: '平行四边形' },
            { name: 'trapezoid', label: '梯形' },
            { name: 'hexagon', label: '六边形' }
        ];
        
        const picker = document.createElement('div');
        picker.className = 'context-menu';
        picker.style.display = 'block';
        picker.style.position = 'fixed';
        picker.style.left = this.contextMenu.style.left;
        picker.style.top = (parseInt(this.contextMenu.style.top) + 50) + 'px';
        picker.style.background = 'white';
        picker.style.border = '1px solid #ddd';
        picker.style.borderRadius = '4px';
        picker.style.boxShadow = '0 4px 12px rgba(0,0,0,0.15)';
        picker.style.zIndex = '2001';
        picker.style.minWidth = '150px';

        shapes.forEach(shape => {
            const option = document.createElement('div');
            option.className = 'context-menu-item';
            option.textContent = shape.label;
            option.style.padding = '8px 12px';
            option.style.cursor = 'pointer';
            
            // 标记当前形状
            if (this.selectedNode.shape === shape.name || 
                (!this.selectedNode.shape && shape.name === 'rectangle')) {
                option.style.background = '#e3f2fd';
                option.style.fontWeight = 'bold';
            }
            
            option.onclick = () => {
                this.changeNodeShape(this.selectedNode, shape.name);
                picker.remove();
            };
            
            option.onmouseover = () => {
                option.style.background = '#f5f5f5';
            };
            
            option.onmouseout = () => {
                if (this.selectedNode.shape === shape.name || 
                    (!this.selectedNode.shape && shape.name === 'rectangle')) {
                    option.style.background = '#e3f2fd';
                } else {
                    option.style.background = 'transparent';
                }
            };
            
            picker.appendChild(option);
        });

        document.body.appendChild(picker);
        
        // 点击其他地方关闭
        setTimeout(() => {
            const closeHandler = (e) => {
                if (!picker.contains(e.target)) {
                    picker.remove();
                    document.removeEventListener('click', closeHandler);
                }
            };
            document.addEventListener('click', closeHandler);
        }, 100);
        
        this.hideContextMenu();
    }

    changeNodeShape(node, shapeName) {
        if (!node || !node.element) return;
        
        // 移除所有形状类
        const shapeClasses = ['shape-rectangle', 'shape-rounded', 'shape-ellipse', 
                             'shape-diamond', 'shape-parallelogram', 'shape-trapezoid', 'shape-hexagon'];
        shapeClasses.forEach(cls => node.element.classList.remove(cls));
        
        // 添加新形状类
        node.element.classList.add(`shape-${shapeName}`);
        node.shape = shapeName;
        
        // 更新连接线
        this.updateConnections();
    }

    cycleNodeShape() {
        if (!this.selectedNode) return;
        
        const shapes = ['rectangle', 'rounded', 'ellipse', 'diamond', 
                       'parallelogram', 'trapezoid', 'hexagon'];
        const currentShape = this.selectedNode.shape || 'rectangle';
        const currentIndex = shapes.indexOf(currentShape);
        const nextIndex = (currentIndex + 1) % shapes.length;
        
        this.changeNodeShape(this.selectedNode, shapes[nextIndex]);
    }

    toggleLayout() {
        if (!this.selectedNode || this.selectedNode.parent) return;
        
        const node = this.selectedNode;
        const currentLayout = node.layout || 'horizontal';
        const newLayout = currentLayout === 'horizontal' ? 'vertical' : 'horizontal';
        
        node.layout = newLayout;
        
        // 清除所有子节点的手动调整标记
        const clearManualPositioning = (n) => {
            n.manuallyPositioned = false;
            n.children.forEach(child => clearManualPositioning(child));
        };
        clearManualPositioning(node);
        
        // 重新布局该节点的所有子树
        this.relayoutTree(node);
        
        // 更新连接线
        this.updateConnections();
        
        this.hideContextMenu();
    }

    relayoutTree(rootNode) {
        // 使用根节点的布局方向递归布局整棵树
        const layout = rootNode.layout || 'horizontal';
        this.relayoutChildren(rootNode, layout);
    }

    relayoutChildren(parentNode, layout) {
        if (!parentNode.children || parentNode.children.length === 0) return;
        
        const children = parentNode.children;
        
        if (layout === 'horizontal') {
            // 横向布局：子节点在右侧垂直排列
            const startY = parentNode.y - (children.length - 1) * 40;
            children.forEach((child, index) => {
                // 只更新未手动调整的节点
                if (!child.manuallyPositioned) {
                    child.x = parentNode.x + 200;
                    child.y = startY + index * 80;
                    child.element.style.left = child.x + 'px';
                    child.element.style.top = child.y + 'px';
                }
                
                // 递归布局子节点
                this.relayoutChildren(child, layout);
            });
        } else {
            // 纵向布局：子节点在下方横向排列
            const startX = parentNode.x - (children.length - 1) * 60;
            children.forEach((child, index) => {
                // 只更新未手动调整的节点
                if (!child.manuallyPositioned) {
                    child.x = startX + index * 120;
                    child.y = parentNode.y + 120;
                    child.element.style.left = child.x + 'px';
                    child.element.style.top = child.y + 'px';
                }
                
                // 递归布局子节点
                this.relayoutChildren(child, layout);
            });
        }
    }

    startArrowConnection() {
        if (!this.selectedNode) return;
        
        // 直接创建一个临时箭头连接
        const tempConnection = {
            source: this.selectedNode,
            target: null,
            isTemporary: true,
            endX: this.selectedNode.x + this.selectedNode.element.offsetWidth / 2 + 100,
            endY: this.selectedNode.y + this.selectedNode.element.offsetHeight / 2
        };
        
        this.arrowConnections.push(tempConnection);
        this.updateConnections();
        this.hideContextMenu();
        
        // 提示用户可以拖动箭头
        const hint = document.createElement('div');
        hint.id = 'connection-hint';
        hint.style.position = 'fixed';
        hint.style.top = '70px';
        hint.style.left = '50%';
        hint.style.transform = 'translateX(-50%)';
        hint.style.background = '#FF6B6B';
        hint.style.color = 'white';
        hint.style.padding = '10px 20px';
        hint.style.borderRadius = '4px';
        hint.style.boxShadow = '0 2px 8px rgba(0,0,0,0.2)';
        hint.style.zIndex = '2000';
        hint.textContent = '拖动箭头到目标位置，松开时自动连接最近的节点';
        document.body.appendChild(hint);
        
        setTimeout(() => hint.remove(), 3000);
    }

    showDeleteArrowMenu() {
        if (!this.selectedNode) return;
        
        const outgoingArrows = this.arrowConnections.filter(
            conn => conn.source === this.selectedNode
        );
        
        if (outgoingArrows.length === 0) return;
        
        // 创建子菜单
        const submenu = document.createElement('div');
        submenu.className = 'context-menu';
        submenu.id = 'arrow-delete-submenu';
        submenu.style.display = 'block';
        submenu.style.position = 'fixed';
        submenu.style.left = (parseInt(this.contextMenu.style.left) + this.contextMenu.offsetWidth) + 'px';
        submenu.style.top = this.contextMenu.style.top;
        submenu.style.zIndex = '2001';
        
        // 添加删除全部选项
        if (outgoingArrows.length > 1) {
            const deleteAllItem = document.createElement('div');
            deleteAllItem.className = 'context-menu-item';
            deleteAllItem.textContent = '删除全部箭头';
            deleteAllItem.style.color = '#FF6B6B';
            deleteAllItem.onclick = () => {
                outgoingArrows.forEach(arrow => {
                    this.deleteArrowConnection(arrow.source, arrow.target);
                });
                submenu.remove();
                this.hideContextMenu();
            };
            submenu.appendChild(deleteAllItem);
            
            const separator = document.createElement('div');
            separator.className = 'context-menu-separator';
            submenu.appendChild(separator);
        }
        
        // 为每个箭头连接添加删除选项
        outgoingArrows.forEach(arrow => {
            const item = document.createElement('div');
            item.className = 'context-menu-item';
            item.textContent = `→ ${arrow.target.text}`;
            item.onclick = () => {
                this.deleteArrowConnection(arrow.source, arrow.target);
                submenu.remove();
                this.hideContextMenu();
            };
            submenu.appendChild(item);
        });
        
        document.body.appendChild(submenu);
        
        // 点击其他地方关闭子菜单
        setTimeout(() => {
            const closeSubmenu = (e) => {
                if (!submenu.contains(e.target)) {
                    submenu.remove();
                    document.removeEventListener('click', closeSubmenu);
                }
            };
            document.addEventListener('click', closeSubmenu);
        }, 100);
        
        this.hideContextMenu();
    }

    createArrowConnection(sourceNode, targetNode) {
        // 检查是否已存在相同的连接
        const exists = this.arrowConnections.some(
            conn => conn.source === sourceNode && conn.target === targetNode
        );
        
        if (!exists) {
            this.arrowConnections.push({
                source: sourceNode,
                target: targetNode,
                id: `arrow-${sourceNode.id}-${targetNode.id}`
            });
            this.updateConnections();
        }
    }

    deleteArrowConnection(sourceNode, targetNode) {
        this.arrowConnections = this.arrowConnections.filter(
            conn => !(conn.source === sourceNode && conn.target === targetNode)
        );
        this.updateConnections();
    }

    toggleHelp() {
        const panel = document.getElementById('help-panel');
        panel.style.display = panel.style.display === 'none' ? 'block' : 'none';
    }

    handleCanvasContextMenu(e) {
        // 只在空白区域右键才显示画布菜单
        if (e.target === this.canvasContainer || e.target === this.canvas || e.target === this.svgCanvas) {
            e.preventDefault();
            e.stopPropagation();
            
            // 保存右键位置，用于创建文本框
            this.canvasContextMenuX = e.clientX;
            this.canvasContextMenuY = e.clientY;
            
            this.showCanvasContextMenu(e.clientX, e.clientY);
        }
    }

    showCanvasContextMenu(x, y) {
        this.canvasContextMenu.style.display = 'block';
        this.canvasContextMenu.style.left = x + 'px';
        this.canvasContextMenu.style.top = y + 'px';

        // 动态在画布右键菜单加入“管理存档”入口（合并保存/加载到一个管理界面）
        if (this.canvasContextMenu && !this._canvasMenuExtended) {
            try {
                const manageItem = document.createElement('div');
                manageItem.className = 'context-menu-item';
                manageItem.textContent = '管理存档 (localStorage)';
                manageItem.onclick = () => { 
                    // 尝试使用根节点名作为默认文件名
                    const root = this.getRootNode ? this.getRootNode(this.selectedNode || null) : null;
                    const defaultName = (root && root.text) ? root.text : '';
                    if (typeof this.openSaveLoadModal === 'function') this.openSaveLoadModal(defaultName);
                    else this.showSavePrompt();
                };

                const sep = document.createElement('div');
                sep.className = 'context-menu-separator';

                this.canvasContextMenu.appendChild(sep);
                this.canvasContextMenu.appendChild(manageItem);
                this._canvasMenuExtended = true;
            } catch (err) {
                console.error(err);
            }
        }
    }

    hideCanvasContextMenu() {
        this.canvasContextMenu.style.display = 'none';
    }

    createTextBox(event) {
        const containerRect = this.canvasContainer.getBoundingClientRect();
        const x = (this.canvasContextMenuX - containerRect.left - this.translateX) / this.scale;
        const y = (this.canvasContextMenuY - containerRect.top - 60 - this.translateY) / this.scale;
        
        const textBox = {
            id: this.textBoxIdCounter++,
            x: x,
            y: y,
            text: '双击编辑',
            rotation: 0
        };
        
        this.textBoxes.push(textBox);
        this.createTextBoxElement(textBox);
        this.hideCanvasContextMenu();
    }

    createTextBoxElement(textBox) {
        const boxEl = document.createElement('div');
        boxEl.className = 'text-box';
        boxEl.id = `textbox-${textBox.id}`;
        boxEl.style.left = textBox.x + 'px';
        boxEl.style.top = textBox.y + 'px';
        boxEl.style.transform = `rotate(${textBox.rotation}deg)`;
        boxEl.style.transformOrigin = 'center center';
        
        const contentEl = document.createElement('span');
        contentEl.className = 'text-box-content';
        contentEl.contentEditable = false;
        contentEl.textContent = textBox.text;
        boxEl.appendChild(contentEl);
        
        // 旋转手柄
        const rotateHandle = document.createElement('div');
        rotateHandle.className = 'text-box-rotate-handle';
        rotateHandle.innerHTML = '↻';
        rotateHandle.title = '拖动旋转';
        boxEl.appendChild(rotateHandle);
        
        // 删除按钮
        const deleteBtn = document.createElement('div');
        deleteBtn.className = 'text-box-delete-btn';
        deleteBtn.innerHTML = '×';
        deleteBtn.title = '删除文本框';
        deleteBtn.onclick = (e) => {
            e.stopPropagation();
            this.deleteTextBox(textBox);
        };
        boxEl.appendChild(deleteBtn);
        
        // 点击选中
        boxEl.addEventListener('click', (e) => {
            e.stopPropagation();
            this.selectTextBox(textBox);
        });
        
        // 双击编辑
        let blurHandler = null;
        boxEl.addEventListener('dblclick', (e) => {
            e.stopPropagation();
            
            // 移除之前的blur监听器
            if (blurHandler) {
                contentEl.removeEventListener('blur', blurHandler);
            }
            
            contentEl.contentEditable = true;
            contentEl.focus();
            
            // 选中所有文本
            const range = document.createRange();
            range.selectNodeContents(contentEl);
            const selection = window.getSelection();
            selection.removeAllRanges();
            selection.addRange(range);
            
            blurHandler = () => {
                textBox.text = contentEl.textContent || '文本';
                contentEl.contentEditable = false;
            };
            
            contentEl.addEventListener('blur', blurHandler, { once: true });
            
            // 按Enter完成编辑
            const enterHandler = (e) => {
                if (e.key === 'Enter') {
                    e.preventDefault();
                    contentEl.blur();
                }
            };
            contentEl.addEventListener('keydown', enterHandler, { once: true });
        });
        
        // 拖动文本框
        boxEl.addEventListener('mousedown', (e) => {
            if (e.target === rotateHandle) return; // 旋转手柄不触发拖动
            if (e.target === deleteBtn) return; // 删除按钮不触发拖动
            if (contentEl.contentEditable === 'true') return; // 编辑模式不拖动
            
            e.stopPropagation();
            this.startDraggingTextBox(textBox, e);
        });
        
        // 旋转功能
        rotateHandle.addEventListener('mousedown', (e) => {
            e.stopPropagation();
            this.startRotatingTextBox(textBox, e);
        });
        
        this.canvas.appendChild(boxEl);
        textBox.element = boxEl;
    }

    // --- localStorage save/load 功能 ---
    // 列出 localStorage 中以 umind: 前缀保存的文件名数组
    listSavedMaps() {
        const keys = [];
        for (let i = 0; i < localStorage.length; i++) {
            const k = localStorage.key(i);
            if (k && k.startsWith('umind:')) {
                keys.push(k.slice('umind:'.length));
            }
        }
        return keys.sort();
    }

    showSavePrompt() {
        // 使用更好的 modal 替代 prompt/alert
        if (typeof this.openSaveLoadModal === 'function') {
            this.openSaveLoadModal();
        } else {
            // fallback
            const name = window.prompt('请输入保存名称（用于 localStorage，区分大小写）：');
            if (!name) return;
            try { this.saveToLocalStorage(name); window.alert('保存成功：' + name); } catch (err) { console.error(err); window.alert('保存失败：' + err.message); }
        }
    }

    showLoadPrompt() {
        // 使用 modal 界面进行选择加载
        if (typeof this.openSaveLoadModal === 'function') {
            this.openSaveLoadModal();
        } else {
            const list = this.listSavedMaps();
            if (!list || list.length === 0) { window.alert('没有找到保存在 localStorage 的文件。'); return; }
            let msg = '请选择要加载的文件名或输入名称：\n';
            list.forEach((n, idx) => { msg += `${idx + 1}. ${n}\n`; });
            msg += '\n你可以输入序号或文件名（区分大小写）。';
            const choice = window.prompt(msg);
            if (!choice) return;
            let name = choice; const num = parseInt(choice, 10);
            if (!isNaN(num) && num >= 1 && num <= list.length) name = list[num - 1];
            if (!name) return;
            try { this.loadFromLocalStorage(name); window.alert('已加载：' + name); } catch (err) { console.error(err); window.alert('加载失败：' + err.message); }
        }
    }

    saveToLocalStorage(name) {
        const key = 'umind:' + name;
        // 序列化节点：只保存纯数据而非 DOM 引用
        const nodes = this.nodes.map(n => ({
            id: n.id,
            text: n.text,
            x: n.x,
            y: n.y,
            parentId: n.parent ? n.parent.id : null,
            color: n.color || null,
            shape: n.shape || null,
            collapsed: !!n.collapsed,
            isRoot: !!n.isRoot
        }));

        const arrows = this.arrowConnections.map(a => ({
            sourceId: a.source ? a.source.id : null,
            targetId: a.target ? a.target.id : null,
            // 保存临时端点以便导入时复原临时箭头（可选）
            isTemporary: !!a.isTemporary,
            endX: a.endX || null,
            endY: a.endY || null
        }));

        const textBoxes = this.textBoxes.map(t => ({ id: t.id, x: t.x, y: t.y, text: t.text, rotation: t.rotation }));
        const dashed = this.dashedBoxes.map(d => ({ id: d.id, x: d.x, y: d.y, width: d.width, height: d.height }));

        const payload = {
            meta: { savedAt: new Date().toISOString(), version: 1 },
            nodes,
            arrows,
            textBoxes,
            dashed,
            view: { scale: this.scale, translateX: this.translateX, translateY: this.translateY }
        };

        localStorage.setItem(key, JSON.stringify(payload));
    }

    loadFromLocalStorage(name) {
        const key = 'umind:' + name;
        const raw = localStorage.getItem(key);
        if (!raw) throw new Error('未找到名称为 "' + name + '" 的存档');
        const payload = JSON.parse(raw);

        // 清理当前内容（移除 DOM）
        this.nodes.forEach(n => { if (n.element) n.element.remove(); });
        this.textBoxes.forEach(t => { if (t.element) t.element.remove(); });
        this.dashedBoxes.forEach(d => { if (d.element) d.element.remove(); });
        // 清空 svg
        this.svgCanvas.innerHTML = '';
        this.initSVGMarkers();

        // 重建数据结构
        this.nodes = [];
        this.arrowConnections = [];
        this.textBoxes = [];
        this.dashedBoxes = [];

        const idMap = new Map();
        // 先创建所有节点对象（不设置 parent）
        payload.nodes.forEach(nd => {
            const node = {
                id: nd.id,
                text: nd.text,
                x: nd.x,
                y: nd.y,
                parent: null,
                children: [],
                isRoot: !!nd.isRoot,
                color: nd.color,
                shape: nd.shape
            };
            idMap.set(node.id, node);
            this.nodes.push(node);
        });

        // 恢复父子关系
        this.nodes.forEach(n => {
            const rawNode = payload.nodes.find(r => r.id === n.id);
            if (rawNode && rawNode.parentId !== null) {
                const p = idMap.get(rawNode.parentId);
                if (p) {
                    n.parent = p;
                    p.children.push(n);
                }
            }
        });

        // 更新计数器
        const maxId = this.nodes.reduce((m, v) => Math.max(m, v.id || 0), 0);
        this.nodeIdCounter = maxId + 1;

        // 创建 DOM 元素
        this.nodes.forEach(n => this.createNodeElement(n));

        // 恢复文本框
        if (payload.textBoxes) {
            payload.textBoxes.forEach(t => {
                const tb = { id: t.id, x: t.x, y: t.y, text: t.text, rotation: t.rotation };
                this.textBoxes.push(tb);
                this.createTextBoxElement(tb);
            });
        }

        // 恢复虚线框
        if (payload.dashed) {
            payload.dashed.forEach(d => {
                const db = { id: d.id, x: d.x, y: d.y, width: d.width, height: d.height };
                this.dashedBoxes.push(db);
                this.createDashedBoxElement(db);
            });
        }

        // 恢复箭头连接
        if (payload.arrows) {
            payload.arrows.forEach(a => {
                const src = idMap.get(a.sourceId);
                const tgt = idMap.get(a.targetId);
                const conn = { source: src, target: tgt, isTemporary: !!a.isTemporary };
                if (a.isTemporary) { conn.endX = a.endX; conn.endY = a.endY; }
                this.arrowConnections.push(conn);
            });
        }

        // 恢复视图
        if (payload.view) {
            this.scale = payload.view.scale || 1;
            this.translateX = payload.view.translateX || 0;
            this.translateY = payload.view.translateY || 0;
            this.updateCanvas();
        }

        // 更新折叠按钮显示和连接
        this.nodes.forEach(n => {
            // 恢复 collapsed 标志
            const rawNode = payload.nodes.find(r => r.id === n.id);
            if (rawNode) n.collapsed = !!rawNode.collapsed;
            if (n._collapseBtn) this.updateCollapseButton(n);
            if (n.collapsed) this.collapseNode(n);
        });

        this.updateConnections();
    }

    selectTextBox(textBox) {
        // 取消所有选中
        this.textBoxes.forEach(tb => {
            if (tb.element) {
                tb.element.classList.remove('selected');
            }
        });
        
        this.dashedBoxes.forEach(db => {
            if (db.element) {
                db.element.classList.remove('selected');
            }
        });
        
        if (this.selectedNode) {
            this.selectedNode.element.classList.remove('selected');
            this.selectedNode = null;
        }
        
        this.selectedDashedBox = null;
        
        // 选中当前文本框
        textBox.element.classList.add('selected');
        this.selectedTextBox = textBox;
    }

    startDraggingTextBox(textBox, e) {
        this.isDraggingTextBox = true;
        this.dragTextBox = textBox;
        
        const rect = textBox.element.getBoundingClientRect();
        this.dragOffsetX = e.clientX - rect.left;
        this.dragOffsetY = e.clientY - rect.top;
        
        this.selectTextBox(textBox);
        
        const onMouseMove = (e) => {
            if (!this.isDraggingTextBox) return;
            
            const containerRect = this.canvasContainer.getBoundingClientRect();
            const x = (e.clientX - containerRect.left - this.dragOffsetX) / this.scale - this.translateX / this.scale;
            const y = (e.clientY - containerRect.top - 60 - this.dragOffsetY) / this.scale - this.translateY / this.scale;
            
            textBox.x = x;
            textBox.y = y;
            textBox.element.style.left = x + 'px';
            textBox.element.style.top = y + 'px';
        };
        
        const onMouseUp = () => {
            this.isDraggingTextBox = false;
            this.dragTextBox = null;
            document.removeEventListener('mousemove', onMouseMove);
            document.removeEventListener('mouseup', onMouseUp);
        };
        
        document.addEventListener('mousemove', onMouseMove);
        document.addEventListener('mouseup', onMouseUp);
    }

    startRotatingTextBox(textBox, e) {
        e.stopPropagation();
        e.preventDefault();
        
        // 获取文本框的中心点（考虑缩放和平移）
        const boxRect = textBox.element.getBoundingClientRect();
        const containerRect = this.canvasContainer.getBoundingClientRect();
        
        // 文本框中心点的屏幕坐标
        const centerScreenX = boxRect.left + boxRect.width / 2;
        const centerScreenY = boxRect.top + boxRect.height / 2;
        
        const onMouseMove = (moveEvent) => {
            // 计算鼠标相对于文本框中心的角度
            const dx = moveEvent.clientX - centerScreenX;
            const dy = moveEvent.clientY - centerScreenY;
            let angle = Math.atan2(dy, dx) * (180 / Math.PI);
            
            // 调整角度（从水平右方向开始，顺时针为正）
            angle = angle + 90;
            
            // 可选：按住Shift键时每15度对齐
            if (moveEvent.shiftKey) {
                angle = Math.round(angle / 15) * 15;
            }
            
            textBox.rotation = Math.round(angle);
            textBox.element.style.transform = `rotate(${textBox.rotation}deg)`;
        };
        
        const onMouseUp = () => {
            document.removeEventListener('mousemove', onMouseMove);
            document.removeEventListener('mouseup', onMouseUp);
        };
        
        document.addEventListener('mousemove', onMouseMove);
        document.addEventListener('mouseup', onMouseUp);
    }

    deleteTextBox(textBox) {
        const index = this.textBoxes.indexOf(textBox);
        if (index > -1) {
            this.textBoxes.splice(index, 1);
            textBox.element.remove();
        }
        this.selectedTextBox = null;
    }

    createDashedBox(event) {
        const containerRect = this.canvasContainer.getBoundingClientRect();
        const x = (this.canvasContextMenuX - containerRect.left - this.translateX) / this.scale;
        const y = (this.canvasContextMenuY - containerRect.top - 60 - this.translateY) / this.scale;
        
        const dashedBox = {
            id: this.dashedBoxIdCounter++,
            x: x,
            y: y,
            width: 200,
            height: 150
        };
        
        this.dashedBoxes.push(dashedBox);
        this.createDashedBoxElement(dashedBox);
        this.hideCanvasContextMenu();
    }

    createDashedBoxElement(dashedBox) {
        const boxEl = document.createElement('div');
        boxEl.className = 'dashed-box';
        boxEl.id = `dashedbox-${dashedBox.id}`;
        boxEl.style.left = dashedBox.x + 'px';
        boxEl.style.top = dashedBox.y + 'px';
        boxEl.style.width = dashedBox.width + 'px';
        boxEl.style.height = dashedBox.height + 'px';
        
        // 创建8个缩放手柄
        const handles = ['nw', 'n', 'ne', 'e', 'se', 's', 'sw', 'w'];
        handles.forEach(pos => {
            const handle = document.createElement('div');
            handle.className = `dashed-box-resize-handle ${pos}`;
            handle.dataset.position = pos;
            
            handle.addEventListener('mousedown', (e) => {
                e.stopPropagation();
                this.startResizingDashedBox(dashedBox, pos, e);
            });
            
            boxEl.appendChild(handle);
        });
        
        // 删除按钮
        const deleteBtn = document.createElement('div');
        deleteBtn.className = 'dashed-box-delete-btn';
        deleteBtn.innerHTML = '×';
        deleteBtn.title = '删除虚线框';
        deleteBtn.onclick = (e) => {
            e.stopPropagation();
            this.deleteDashedBox(dashedBox);
        };
        boxEl.appendChild(deleteBtn);
        
        // 点击选中
        boxEl.addEventListener('click', (e) => {
            e.stopPropagation();
            this.selectDashedBox(dashedBox);
        });
        
        // 拖动虚线框
        boxEl.addEventListener('mousedown', (e) => {
            // 如果点击的是缩放手柄或删除按钮，不触发拖动
            if (e.target.classList.contains('dashed-box-resize-handle') || 
                e.target.classList.contains('dashed-box-delete-btn')) {
                return;
            }
            
            e.stopPropagation();
            this.startDraggingDashedBox(dashedBox, e);
        });
        
        this.canvas.appendChild(boxEl);
        dashedBox.element = boxEl;
    }

    selectDashedBox(dashedBox) {
        // 取消所有选中
        this.dashedBoxes.forEach(db => {
            if (db.element) {
                db.element.classList.remove('selected');
            }
        });
        
        this.textBoxes.forEach(tb => {
            if (tb.element) {
                tb.element.classList.remove('selected');
            }
        });
        
        if (this.selectedNode) {
            this.selectedNode.element.classList.remove('selected');
            this.selectedNode = null;
        }
        
        this.selectedTextBox = null;
        
        // 选中当前虚线框
        dashedBox.element.classList.add('selected');
        this.selectedDashedBox = dashedBox;
    }

    startDraggingDashedBox(dashedBox, e) {
        this.isDraggingDashedBox = true;
        this.dragDashedBox = dashedBox;
        
        const rect = dashedBox.element.getBoundingClientRect();
        this.dragOffsetX = e.clientX - rect.left;
        this.dragOffsetY = e.clientY - rect.top;
        
        this.selectDashedBox(dashedBox);
        
        const onMouseMove = (e) => {
            if (!this.isDraggingDashedBox) return;
            
            const containerRect = this.canvasContainer.getBoundingClientRect();
            const x = (e.clientX - containerRect.left - this.dragOffsetX) / this.scale - this.translateX / this.scale;
            const y = (e.clientY - containerRect.top - 60 - this.dragOffsetY) / this.scale - this.translateY / this.scale;
            
            dashedBox.x = x;
            dashedBox.y = y;
            dashedBox.element.style.left = x + 'px';
            dashedBox.element.style.top = y + 'px';
        };
        
        const onMouseUp = () => {
            this.isDraggingDashedBox = false;
            this.dragDashedBox = null;
            document.removeEventListener('mousemove', onMouseMove);
            document.removeEventListener('mouseup', onMouseUp);
        };
        
        document.addEventListener('mousemove', onMouseMove);
        document.addEventListener('mouseup', onMouseUp);
    }

    startResizingDashedBox(dashedBox, position, e) {
        e.stopPropagation();
        e.preventDefault();
        
        this.isResizingDashedBox = true;
        this.resizeDashedBox = dashedBox;
        this.resizeHandle = position;
        
        const startX = e.clientX;
        const startY = e.clientY;
        const startBoxX = dashedBox.x;
        const startBoxY = dashedBox.y;
        const startWidth = dashedBox.width;
        const startHeight = dashedBox.height;
        
        const onMouseMove = (e) => {
            if (!this.isResizingDashedBox) return;
            
            const containerRect = this.canvasContainer.getBoundingClientRect();
            const dx = (e.clientX - startX) / this.scale;
            const dy = (e.clientY - startY) / this.scale;
            
            let newX = startBoxX;
            let newY = startBoxY;
            let newWidth = startWidth;
            let newHeight = startHeight;
            
            // 根据手柄位置调整尺寸和位置
            if (position.includes('w')) {
                newX = startBoxX + dx;
                newWidth = startWidth - dx;
            }
            if (position.includes('e')) {
                newWidth = startWidth + dx;
            }
            if (position.includes('n')) {
                newY = startBoxY + dy;
                newHeight = startHeight - dy;
            }
            if (position.includes('s')) {
                newHeight = startHeight + dy;
            }
            
            // 最小尺寸限制
            if (newWidth < 50) {
                if (position.includes('w')) {
                    newX = startBoxX + startWidth - 50;
                }
                newWidth = 50;
            }
            if (newHeight < 50) {
                if (position.includes('n')) {
                    newY = startBoxY + startHeight - 50;
                }
                newHeight = 50;
            }
            
            dashedBox.x = newX;
            dashedBox.y = newY;
            dashedBox.width = newWidth;
            dashedBox.height = newHeight;
            
            dashedBox.element.style.left = newX + 'px';
            dashedBox.element.style.top = newY + 'px';
            dashedBox.element.style.width = newWidth + 'px';
            dashedBox.element.style.height = newHeight + 'px';
        };
        
        const onMouseUp = () => {
            this.isResizingDashedBox = false;
            this.resizeDashedBox = null;
            this.resizeHandle = null;
            document.removeEventListener('mousemove', onMouseMove);
            document.removeEventListener('mouseup', onMouseUp);
        };
        
        document.addEventListener('mousemove', onMouseMove);
        document.addEventListener('mouseup', onMouseUp);
    }

    deleteDashedBox(dashedBox) {
        // 删除与此虚线框相关的所有箭头连接
        this.arrowConnections = this.arrowConnections.filter(
            conn => conn.source !== dashedBox && conn.target !== dashedBox
        );
        
        const index = this.dashedBoxes.indexOf(dashedBox);
        if (index > -1) {
            this.dashedBoxes.splice(index, 1);
            dashedBox.element.remove();
        }
        this.selectedDashedBox = null;
        this.updateConnections();
    }

    showCanvasColorPicker() {
        const colors = [
            '#FFFFFF', '#F5F5F5', '#E8F4F8', '#FFF9E6', 
            '#F0F8FF', '#E6F3E6', '#FFF0F5', '#F5F5DC'
        ];
        
        const picker = document.createElement('div');
        picker.className = 'context-menu color-picker';
        picker.style.display = 'flex';
        picker.style.flexWrap = 'wrap';
        picker.style.width = '200px';
        picker.style.position = 'fixed';
        picker.style.left = this.canvasContextMenu.style.left;
        picker.style.top = this.canvasContextMenu.style.top;
        picker.style.background = 'white';
        picker.style.border = '1px solid #ddd';
        picker.style.borderRadius = '4px';
        picker.style.boxShadow = '0 4px 12px rgba(0,0,0,0.15)';
        picker.style.zIndex = '2001';
        picker.style.padding = '10px';

        colors.forEach(color => {
            const option = document.createElement('div');
            option.className = 'color-option';
            option.style.background = color;
            option.style.border = '2px solid #ddd';
            option.onclick = () => {
                this.canvas.style.backgroundColor = color;
                picker.remove();
            };
            picker.appendChild(option);
        });

        document.body.appendChild(picker);
        setTimeout(() => picker.remove(), 5000);
        this.hideCanvasContextMenu();
    }

    exportJSON() {
        const data = {
            version: '1.3',
            canvasBackgroundColor: this.canvas.style.backgroundColor || '#ffffff',
            nodes: this.nodes.map(node => ({
                id: node.id,
                text: node.text,
                x: node.x,
                y: node.y,
                parentId: node.parent ? node.parent.id : null,
                isRoot: node.isRoot,
                color: node.color,
                shape: node.shape || 'rectangle',
                layout: node.layout || 'horizontal',
            })),
            arrowConnections: this.arrowConnections
                .filter(conn => !conn.isTemporary && conn.target) // 只导出完成的箭头
                .map(conn => ({
                    sourceId: conn.source.id,
                    targetId: conn.target.id,
                    targetType: conn.targetType || 'node' // 'node' 或 'dashedBox'
                })),
            textBoxes: this.textBoxes.map(tb => ({
                id: tb.id,
                x: tb.x,
                y: tb.y,
                text: tb.text,
                rotation: tb.rotation
            })),

            dashedBoxes: this.dashedBoxes.map(db => ({
                id: db.id,
                x: db.x,
                y: db.y,
                width: db.width,
                height: db.height
            }))
        };

        const json = JSON.stringify(data, null, 2);
        const blob = new Blob([json], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
               const a = document.createElement('a');
        a.href = url;
        a.download = 'mindmap.json';
        a.click();
        URL.revokeObjectURL(url);
    }

    importJSON(event) {
        const file = event.target.files[0];
        if (!file) return;

        const reader = new FileReader();
        reader.onload = (e) => {
            try {
                const data = JSON.parse(e.target.result);
                
                // 清空现有数据
                this.nodes.forEach(node => node.element.remove());
                this.textBoxes.forEach(tb => tb.element && tb.element.remove());
                this.dashedBoxes.forEach(db => db.element && db.element.remove());
                this.nodes = [];
                this.connections = [];
                this.arrowConnections = [];
                this.textBoxes = [];
                this.dashedBoxes = [];
                this.selectedNode = null;
                this.selectedTextBox = null;
                this.selectedDashedBox = null;
                this.svgCanvas.innerHTML = '';
                this.initSVGMarkers(); // 重新初始化箭头标记

                // 恢复背景色
                if (data.canvasBackgroundColor) {
                    this.canvas.style.backgroundColor = data.canvasBackgroundColor;
                }

                // 创建节点映射
                const nodeMap = {};
                
                // 第一遍：创建所有节点
                data.nodes.forEach(nodeData => {
                    const node = {
                        id: nodeData.id,
                        text: nodeData.text,
                        x: nodeData.x,
                        y: nodeData.y,
                        parent: null,
                        children: [],
                        isRoot: nodeData.isRoot,
                        color: nodeData.color,
                        shape: nodeData.shape || 'rectangle',
                        layout: nodeData.layout || 'horizontal',
                    };
                    this.nodes.push(node);
                    nodeMap[node.id] = node;
                    this.createNodeElement(node);
                });

                // 第二遍：建立父子关系
                data.nodes.forEach(nodeData => {
                    if (nodeData.parentId !== null) {
                        const node = nodeMap[nodeData.id];
                        const parent = nodeMap[nodeData.parentId];
                        node.parent = parent;
                        parent.children.push(node);
                    }
                });

                // 第三遍：恢复文本框
                if (data.textBoxes) {
                    data.textBoxes.forEach(tbData => {
                        const textBox = {
                            id: tbData.id,
                            x: tbData.x,
                            y: tbData.y,
                            text: tbData.text,
                            rotation: tbData.rotation || 0
                        };
                        this.textBoxes.push(textBox);
                        this.createTextBoxElement(textBox);
                    });
                    if (this.textBoxes.length > 0) {
                        this.textBoxIdCounter = Math.max(...this.textBoxes.map(tb => tb.id)) + 1;
                    }
                }

                // 第四遍：恢复虚线框
                const dashedBoxMap = {};
                if (data.dashedBoxes) {
                    data.dashedBoxes.forEach(dbData => {
                        const dashedBox = {
                            id: dbData.id,
                            x: dbData.x,
                            y: dbData.y,
                            width: dbData.width,
                            height: dbData.height
                        };
                        this.dashedBoxes.push(dashedBox);
                        dashedBoxMap[dashedBox.id] = dashedBox;
                        this.createDashedBoxElement(dashedBox);
                    });
                    if (this.dashedBoxes.length > 0) {
                        this.dashedBoxIdCounter = Math.max(...this.dashedBoxes.map(db => db.id)) + 1;
                    }
                }

                // 第五遍：恢复箭头连接（必须在节点和虚线框都创建后）
                if (data.arrowConnections) {
                    data.arrowConnections.forEach(connData => {
                        const source = nodeMap[connData.sourceId];
                        let target = null;
                        const targetType = connData.targetType || 'node';
                        
                        if (targetType === 'node') {
                            target = nodeMap[connData.targetId];
                        } else if (targetType === 'dashedBox') {
                            target = dashedBoxMap[connData.targetId];
                        }
                        
                        if (source && target) {
                            this.arrowConnections.push({
                                source: source,
                                target: target,
                                targetType: targetType,
                                id: `arrow-${source.id}-${target.id}`
                            });
                        }
                    });
                }

                this.nodeIdCounter = Math.max(...this.nodes.map(n => n.id)) + 1;
                this.updateConnections();
                this.resetView();

            } catch (error) {
                alert('导入失败：' + error.message);
            }
        };
        reader.readAsText(file);
        event.target.value = '';
    }
        
}

// 初始化思维导图
const mindMap = new MindMap();

// Ensure node and canvas context menus have Copy / Paste entries
function ensureCopyPasteMenu() {
    try {
        const nodeMenu = document.getElementById('context-menu');
        const canvasMenu = document.getElementById('canvas-context-menu');
        if (nodeMenu) {
            // avoid duplicates
            if (!nodeMenu.querySelector('.context-menu-item.copy')) {
                const divC = document.createElement('div'); divC.className = 'context-menu-item copy'; divC.textContent = '复制'; divC.onclick = () => { mindMap.copySelection(); hideContextMenu(); };
                const divP = document.createElement('div'); divP.className = 'context-menu-item paste'; divP.textContent = '粘贴'; divP.onclick = () => { mindMap.pasteClipboard(); hideContextMenu(); };
                // insert at top after existing first item if possible
                if (nodeMenu.firstChild) nodeMenu.insertBefore(divP, nodeMenu.firstChild.nextSibling);
                nodeMenu.insertBefore(divC, nodeMenu.firstChild.nextSibling);
            }
        }
        if (canvasMenu) {
            if (!canvasMenu.querySelector('.context-menu-item.paste')) {
                const divP = document.createElement('div'); divP.className = 'context-menu-item paste'; divP.textContent = '粘贴'; divP.onclick = (e) => { mindMap.pasteClipboard(); hideCanvasContextMenu(); };
                // append to canvas menu
                canvasMenu.appendChild(divP);
            }
        }
    } catch (e) { console.error('ensureCopyPasteMenu', e); }
}

// call once now and also when document is clicked to ensure persistence
document.addEventListener('DOMContentLoaded', ensureCopyPasteMenu);
setTimeout(ensureCopyPasteMenu, 200);

// --- Clipboard API: copy selected elements (node subtree / text box / dashed box) and paste ---
mindMap._clipboard = null;

mindMap.copySelection = function() {
    const clip = { nodes: [], arrows: [], textBoxes: [], dashedBoxes: [] };
    // node subtree
    if (this.selectedNode) {
        const collect = (n) => {
            clip.nodes.push({ id: n.id, text: n.text, x: n.x, y: n.y, color: n.color, shape: n.shape, collapsed: !!n.collapsed, parentId: n.parent ? n.parent.id : null });
            n.children.forEach(c => collect(c));
        };
        collect(this.selectedNode);
        const ids = new Set(clip.nodes.map(n=>n.id));
        this.arrowConnections.forEach(conn => {
            if (ids.has(conn.source.id) && ids.has(conn.target.id)) clip.arrows.push({ source: conn.source.id, target: conn.target.id, points: conn.points || null });
        });
    }
    // text box
    if (this.selectedTextBox) {
        const t = this.selectedTextBox;
        clip.textBoxes.push({ x: t.x, y: t.y, width: t.width, height: t.height, text: t.text, rotation: t.rotation });
    }
    // dashed box
    if (this.selectedDashedBox) {
        const d = this.selectedDashedBox;
        clip.dashedBoxes.push({ x: d.x, y: d.y, width: d.width, height: d.height });
    }
    if (clip.nodes.length===0 && clip.textBoxes.length===0 && clip.dashedBoxes.length===0) return false;
    this._clipboard = clip;
    return true;
};

mindMap.pasteClipboard = function(offsetX=30, offsetY=30) {
    if (!this._clipboard) return false;
    const map = this._clipboard;
    const oldToNew = new Map();
    const created = [];

    // Paste nodes
    if (map.nodes && map.nodes.length) {
        // create nodes
        map.nodes.forEach(n => {
            const nn = { id: this.nodeIdCounter++, text: n.text, x: n.x + offsetX, y: n.y + offsetY, parent: null, children: [], isRoot: false, color: n.color, shape: n.shape, collapsed: n.collapsed };
            this.nodes.push(nn); oldToNew.set(n.id, nn); created.push(nn);
        });
        // restore parent relationships within the pasted set
        map.nodes.forEach(n => {
            const newNode = oldToNew.get(n.id);
            if (!n.parentId) {
                // attach to currently selected node if any, otherwise keep unattached
                if (this.selectedNode) { newNode.parent = this.selectedNode; this.selectedNode.children.push(newNode); }
            } else {
                const newParent = oldToNew.get(n.parentId);
                if (newParent) { newNode.parent = newParent; newParent.children.push(newNode); }
            }
        });
        // create DOM elements
        created.forEach(n => { this.createNodeElement(n); if (n.parent && n.parent.collapsed) n.element.style.display = 'none'; });
    }

    // Paste text boxes
    if (map.textBoxes && map.textBoxes.length) {
        map.textBoxes.forEach(t => {
            const tb = { id: 'tb_' + Date.now() + Math.random().toString(36).slice(2), x: t.x + offsetX, y: t.y + offsetY, width: t.width, height: t.height, text: t.text, rotation: t.rotation };
            this.textBoxes.push(tb); this.createTextBoxElement(tb);
        });
    }

    // Paste dashed boxes
    if (map.dashedBoxes && map.dashedBoxes.length) {
        map.dashedBoxes.forEach(d => {
            const db = { id: 'db_' + Date.now() + Math.random().toString(36).slice(2), x: d.x + offsetX, y: d.y + offsetY, width: d.width, height: d.height };
            this.dashedBoxes.push(db); this.createDashedBoxElement(db);
        });
    }

    // Paste arrows
    if (map.arrows && map.arrows.length) {
        map.arrows.forEach(a => {
            const s = oldToNew.get(a.source), t = oldToNew.get(a.target);
            if (s && t) { this.arrowConnections.push({ source: s, target: t, points: a.points || null }); }
        });
    }

    this.updateConnections();
    return true;
};

// --- Save/Load modal UI (injected CSS + modal DOM) ---
;(function() {
        // Inject styles once
        const css = `
        .umind-modal-backdrop{position:fixed;left:0;top:0;right:0;bottom:0;background:rgba(0,0,0,0.5);display:none;align-items:center;justify-content:center;z-index:3000}
        .umind-modal{width:720px;max-width:95%;background:#fff;border-radius:8px;box-shadow:0 10px 40px rgba(0,0,0,0.3);padding:16px;display:flex;flex-direction:column}
        .umind-modal h3{margin:0 0 8px 0}
        .umind-modal .modal-toolbar{display:flex;gap:8px;align-items:center;margin-bottom:8px}
        .umind-modal .modal-body{display:flex;gap:12px}
        .umind-modal .save-column{display: none;}
        .umind-modal .list-column{flex:1;max-height:400px;overflow:auto;}
        .umind-modal .saved-item{display:flex;align-items:center;justify-content:space-between;padding:8px;border-radius:6px;margin-bottom:6px;background:#fafafa}
        .umind-modal .saved-item .meta{font-size:12px;color:#666}
        .umind-modal .saved-item .actions{display:flex;gap:6px}
        .umind-modal .modal-footer{display:flex;justify-content:flex-end;gap:8px;margin-top:12px}
        .umind-modal input[type="text"]{padding:8px;border:1px solid #ddd;border-radius:4px}
        .umind-modal button{padding:6px 10px;border-radius:4px;border:1px solid #ccc;background:#fff;cursor:pointer}
        .umind-modal button.primary{background:#4A90E2;color:#fff;border-color:#4A90E2}
        .umind-modal .small{padding:4px 8px;font-size:12px}
        .umind-modal .no-saves{color:#888;font-size:13px;padding:12px}
        `;
        const style = document.createElement('style');
        style.type = 'text/css';
        style.appendChild(document.createTextNode(css));
        document.head.appendChild(style);

        // Create modal DOM
        const backdrop = document.createElement('div');
        backdrop.className = 'umind-modal-backdrop';
        backdrop.innerHTML = `
            <div class="umind-modal" role="dialog" aria-modal="true">
                <h3>管理存档（localStorage）</h3>
                <div class="modal-toolbar">
                    <input type="text" id="umind-save-name" placeholder="输入保存名称或选中列表项" />
                    <button id="umind-save-btn" class="primary">保存</button>
                    <select id="umind-sort-select"><option value="time-desc">时间 ↓</option><option value="time-asc">时间 ↑</option><option value="name-asc">名称 A→Z</option><option value="name-desc">名称 Z→A</option></select>
                </div>
                <div class="modal-body">
                    <div class="save-column">
                        <div>当前名称</div>
                        <div style="margin-top:8px"><input type="text" id="umind-rename-input" placeholder="重命名（选中后）" /></div>
                        <div style="margin-top:8px"><button id="umind-rename-btn" class="small">重命名</button> <button id="umind-delete-btn" class="small">删除</button></div>
                    </div>
                    <div class="list-column">
                        <div id="umind-saved-list"></div>
                    </div>
                </div>
                <div class="modal-footer"><button id="umind-cancel-btn">关闭</button></div>
            </div>
        `;
        document.body.appendChild(backdrop);
               
        // Wire up functions on mindMap instance
        function refreshList() {
                const listEl = document.getElementById('umind-saved-list');
                listEl.innerHTML = '';
                const names = mindMap.listSavedMaps();
                if (!names || names.length === 0) {
                        const n = document.createElement('div'); n.className = 'no-saves'; n.textContent = '尚无存档'; listEl.appendChild(n); return;
                }
                // get sort
                const sort = document.getElementById('umind-sort-select').value;
                const items = names.map(name => {
                        const raw = localStorage.getItem('umind:' + name);
                        let meta = null; try { meta = raw ? JSON.parse(raw).meta : null; } catch(e) { meta = null; }
                        return { name, savedAt: (meta && meta.savedAt) ? meta.savedAt : null };
                });
                if (sort === 'time-desc') items.sort((a,b) => (b.savedAt||'').localeCompare(a.savedAt||''));
                else if (sort === 'time-asc') items.sort((a,b) => (a.savedAt||'').localeCompare(b.savedAt||''));
                else if (sort === 'name-asc') items.sort((a,b) => a.name.localeCompare(b.name));
                else if (sort === 'name-desc') items.sort((a,b) => b.name.localeCompare(a.name));

                items.forEach(it => {
                        const row = document.createElement('div'); row.className = 'saved-item';
                        const left = document.createElement('div');
                        const title = document.createElement('div'); title.textContent = it.name; title.style.fontWeight = '600';
                        const meta = document.createElement('div'); meta.className = 'meta'; meta.textContent = it.savedAt ? (new Date(it.savedAt)).toLocaleString() : '';
                        left.appendChild(title); left.appendChild(meta);
                        const actions = document.createElement('div'); actions.className = 'actions';
                        const loadBtn = document.createElement('button'); loadBtn.className = 'small'; loadBtn.textContent = '加载'; loadBtn.onclick = () => { if (confirm('加载将替换当前画布，确定？')) { mindMap.loadFromLocalStorage(it.name); hideModal(); } };
                        const useNameBtn = document.createElement('button'); useNameBtn.className = 'small'; useNameBtn.textContent = '使用'; useNameBtn.onclick = () => { document.getElementById('umind-save-name').value = it.name; document.getElementById('umind-rename-input').value = it.name; };
                        const delBtn = document.createElement('button'); delBtn.className = 'small'; delBtn.textContent = '删除'; delBtn.onclick = () => { if (confirm('确定删除存档：' + it.name + '？')) { localStorage.removeItem('umind:' + it.name); refreshList(); } };
                        actions.appendChild(loadBtn); actions.appendChild(useNameBtn); actions.appendChild(delBtn);
                        row.appendChild(left); row.appendChild(actions);
                        listEl.appendChild(row);
                });
        }

        function showModal() { backdrop.style.display = 'flex'; refreshList(); }
        function hideModal() { backdrop.style.display = 'none'; }

        document.getElementById('umind-cancel-btn').addEventListener('click', hideModal);
        document.getElementById('umind-sort-select').addEventListener('change', refreshList);
        document.getElementById('umind-save-btn').addEventListener('click', () => {
                const name = document.getElementById('umind-save-name').value.trim();
                if (!name) { alert('请输入保存名称'); return; }
                if (localStorage.getItem('umind:' + name) && !confirm('存在同名存档，是否覆盖？')) return;
                mindMap.saveToLocalStorage(name);
                refreshList();
                alert('保存成功：' + name);
        });
        document.getElementById('umind-rename-btn').addEventListener('click', () => {
                const oldName = document.getElementById('umind-rename-input').value.trim();
                const newName = document.getElementById('umind-save-name').value.trim();
                if (!oldName || !newName) { alert('请选择或输入需要重命名的旧名与新名'); return; }
                const oldKey = 'umind:' + oldName; const newKey = 'umind:' + newName;
                const raw = localStorage.getItem(oldKey); if (!raw) { alert('未找到旧存档：' + oldName); return; }
                if (localStorage.getItem(newKey) && !confirm('目标名称已存在，是否覆盖？')) return;
                localStorage.setItem(newKey, raw); localStorage.removeItem(oldKey); refreshList(); alert('重命名成功');
        });
        document.getElementById('umind-delete-btn').addEventListener('click', () => {
                const name = document.getElementById('umind-rename-input').value.trim(); if (!name) { alert('请选择要删除的存档'); return; }
                if (!localStorage.getItem('umind:' + name)) { alert('未找到：' + name); return; }
                if (confirm('确定删除：' + name + '？')) { localStorage.removeItem('umind:' + name); refreshList(); }
        });

        // expose on mindMap object
        mindMap.openSaveLoadModal = showModal;
        mindMap.hideSaveLoadModal = hideModal;
})();